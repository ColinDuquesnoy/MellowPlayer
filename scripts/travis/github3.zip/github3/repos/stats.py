# -*- coding: utf-8 -*-
from __future__ import unicode_literals

from datetime import datetime

from .. import users

from ..models import GitHubCore


def alternate_week(week):
    return {
        'start of week': datetime.fromtimestamp(int(week['w'])),
        'additions': week['a'],
        'deletions': week['d'],
        'commits': week['c'],
    }


class ContributorStats(GitHubCore):

    """This object provides easy access to information returned by the
    statistics section of the API.

    See http://developer.github.com/v3/repos/statistics/ for specifics.

    """

    def _update_attributes(self, stats_object):
        #: Contributor in particular that this relates to
        self.author = self._class_attribute(
            stats_object, 'author', users.ShortUser, self
        )
        #: Total number of commits authored by ``author``.
        self.total = self._get_attribute(stats_object, 'total')
        #: List of weekly dictionaries.
        self.weeks = self._get_attribute(stats_object, 'weeks', [])
        #: Alternative collection of weekly dictionaries
        #: This provides a datetime object and easy to remember keys for each
        #: element in the list.
        #: 'w' -> 'start of week', 'a' -> 'Number of additions',
        #: 'd' -> 'Number of deletions', 'c' -> 'Number of commits'
        self.alt_weeks = self.weeks
        if self.alt_weeks:
            self.alt_weeks = [alternate_week(w) for w in self.weeks]

    def _repr(self):
        return '<Contributor Statistics [{0}]>'.format(self.author)
